// utils/mqtt.js
class MqttClient {
  constructor(wsUrl, clientId) {
    this.wsUrl = wsUrl;
    this.clientId = clientId;
    this.socket = null;
    this.connected = false;
    this.messageCallback = null;
    this._nextPacketId = 1;
  }

  connect(username = '', password = '') {
    return new Promise((resolve, reject) => {
      this.socket = wx.connectSocket({
        url: this.wsUrl,
        success: () => console.log('WebSocket 连接中...'),
        fail: (err) => reject(err)
      });

      this.socket.onOpen(() => {
        console.log('WebSocket 已打开，发送 MQTT CONNECT 报文');
        const connectPacket = this._buildConnectPacket(this.clientId, username, password);
        this._send(connectPacket);
      });

      this.socket.onMessage((res) => {
        this._handleMessage(res.data);
      });

      this.socket.onError((err) => {
        console.error('WebSocket 错误', err);
        this.connected = false;
        reject(err);
      });

      this.socket.onClose(() => {
        console.log('WebSocket 已关闭');
        this.connected = false;
      });

      this._connectResolve = resolve;
      this._connectReject = reject;
    });
  }

  _buildConnectPacket(clientId, username, password) {
    const protocolName = 'MQTT';
    const protocolLevel = 4;
    const connectFlags = 0x02; // Clean Session
    const keepAlive = 60;

    let payloadLen = 0;
    payloadLen += 2 + protocolName.length;
    payloadLen += 1;
    payloadLen += 1;
    payloadLen += 2;
    payloadLen += 2 + clientId.length;
    if (username) payloadLen += 2 + username.length;
    if (password) payloadLen += 2 + password.length;

    const buffer = new ArrayBuffer(payloadLen);
    const dv = new DataView(buffer);
    let offset = 0;

    dv.setUint16(offset, protocolName.length, false); offset += 2;
    for (let i = 0; i < protocolName.length; i++) {
      dv.setUint8(offset, protocolName.charCodeAt(i)); offset++;
    }
    dv.setUint8(offset, protocolLevel); offset++;
    dv.setUint8(offset, connectFlags); offset++;
    dv.setUint16(offset, keepAlive, false); offset += 2;
    dv.setUint16(offset, clientId.length, false); offset += 2;
    for (let i = 0; i < clientId.length; i++) {
      dv.setUint8(offset, clientId.charCodeAt(i)); offset++;
    }
    if (username) {
      dv.setUint16(offset, username.length, false); offset += 2;
      for (let i = 0; i < username.length; i++) {
        dv.setUint8(offset, username.charCodeAt(i)); offset++;
      }
    }
    if (password) {
      dv.setUint16(offset, password.length, false); offset += 2;
      for (let i = 0; i < password.length; i++) {
        dv.setUint8(offset, password.charCodeAt(i)); offset++;
      }
    }

    const remainingLength = payloadLen;
    const fixedHeader = new Uint8Array(2);
    fixedHeader[0] = 0x10;
    fixedHeader[1] = remainingLength;

    const packet = new Uint8Array(fixedHeader.length + payloadLen);
    packet.set(fixedHeader, 0);
    packet.set(new Uint8Array(buffer), fixedHeader.length);
    return packet.buffer;
  }

  _send(buffer) {
    // 关键修正：使用 readyState === 1 而不是 WebSocket.OPEN
    if (this.socket && this.socket.readyState === 1) {
      this.socket.send({ data: buffer });
    } else {
      console.error('WebSocket 未打开，无法发送, readyState:', this.socket?.readyState);
    }
  }

  _handleMessage(data) {
    const bytes = new Uint8Array(data);
    if (bytes.length < 2) return;
    const packetType = bytes[0] >> 4;
    if (packetType === 2) { // CONNACK
      const returnCode = bytes[3];
      if (returnCode === 0) {
        console.log('MQTT CONNACK 成功，连接已建立');
        this.connected = true;
        if (this._connectResolve) this._connectResolve();
      } else {
        console.error('MQTT 连接失败，返回码:', returnCode);
        if (this._connectReject) this._connectReject(new Error(`CONNACK 返回码 ${returnCode}`));
      }
    } else if (packetType === 3) { // PUBLISH
      let pos = 2;
      const topicLen = (bytes[pos] << 8) | bytes[pos + 1];
      pos += 2;
      const topic = this._bytesToString(bytes.slice(pos, pos + topicLen));
      pos += topicLen;
      const payload = this._bytesToString(bytes.slice(pos));
      if (this.messageCallback) {
        this.messageCallback(topic, payload);
      }
    }
  }

  subscribe(topic, qos = 0) {
    if (!this.connected) {
      console.error('尚未连接，无法订阅');
      return;
    }
    const packetId = this._nextPacketId++;
    const topicBytes = this._stringToBytes(topic);
    const variableLen = 2 + 2 + topicBytes.length + 1;
    const fixedHeader = new Uint8Array(2);
    fixedHeader[0] = 0x82;
    fixedHeader[1] = variableLen;

    const buffer = new ArrayBuffer(variableLen);
    const dv = new DataView(buffer);
    let offset = 0;
    dv.setUint16(offset, packetId, false); offset += 2;
    dv.setUint16(offset, topicBytes.length, false); offset += 2;
    for (let i = 0; i < topicBytes.length; i++) {
      dv.setUint8(offset, topicBytes[i]); offset++;
    }
    dv.setUint8(offset, qos); offset++;

    const packet = new Uint8Array(fixedHeader.length + variableLen);
    packet.set(fixedHeader, 0);
    packet.set(new Uint8Array(buffer), fixedHeader.length);
    this._send(packet.buffer);
    console.log('已发送 SUBSCRIBE 报文，主题:', topic);
  }

  onMessage(callback) {
    this.messageCallback = callback;
  }

  _stringToBytes(str) {
    const bytes = new Uint8Array(str.length);
    for (let i = 0; i < str.length; i++) {
      bytes[i] = str.charCodeAt(i);
    }
    return bytes;
  }

  _bytesToString(bytes) {
    let str = '';
    for (let i = 0; i < bytes.length; i++) {
      str += String.fromCharCode(bytes[i]);
    }
    return str;
  }

  disconnect() {
    if (this.socket) {
      this.socket.close();
    }
  }
}

module.exports = { MqttClient };