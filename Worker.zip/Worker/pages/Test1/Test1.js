// pages/Test1/Test1.js
Page({
  data: {
    methaneThreshold: 15,
    distThreshold: 50,
    pm25Threshold: 150
  },

  onLoad() {
    this.loadThresholds();
  },

  loadThresholds() {
    const methane = wx.getStorageSync('alert_methane_threshold');
    const dist = wx.getStorageSync('alert_dist_threshold');
    const pm25 = wx.getStorageSync('alert_pm25_threshold');
    this.setData({
      methaneThreshold: methane !== '' ? Number(methane) : 15,
      distThreshold: dist !== '' ? Number(dist) : 50,
      pm25Threshold: pm25 !== '' ? Number(pm25) : 150
    });
  },

  onMethaneInput(e) {
    this.setData({ methaneThreshold: e.detail.value });
  },
  onDistInput(e) {
    this.setData({ distThreshold: e.detail.value });
  },
  onPm25Input(e) {
    this.setData({ pm25Threshold: e.detail.value });
  },

  saveThresholds() {
    wx.setStorageSync('alert_methane_threshold', Number(this.data.methaneThreshold));
    wx.setStorageSync('alert_dist_threshold', Number(this.data.distThreshold));
    wx.setStorageSync('alert_pm25_threshold', Number(this.data.pm25Threshold));
    wx.showToast({
      title: '保存成功',
      icon: 'success',
      duration: 1500
    });
  },

  resetToDefault() {
    this.setData({
      methaneThreshold:15,
      distThreshold: 50,
      pm25Threshold: 150
    });
    this.saveThresholds();
  }
});