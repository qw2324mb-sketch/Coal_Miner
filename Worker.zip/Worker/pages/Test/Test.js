// pages/Test/Test.js
import * as echarts from '../../components/ec-canvas/echarts';

let chartInstance = null;

Page({
  data: {
    paramList: [
      { name: '温度', value: 'temp', unit: '°C' },
      { name: '湿度', value: 'hum', unit: '%RH' },
      { name: '甲烷浓度', value: 'methane', unit: '%LEL' },
      { name: '顶板距离', value: 'dist', unit: 'cm' },
      { name: 'PM2.5', value: 'pm25', unit: 'µg/m³' }
    ],
    currentParam: 'temp',
    historyCount: 0,
    ec: {}  // 占位，稍后动态赋值
  },

  onLoad() {
    // 动态设置 ec 的 onInit，确保 this 正确
    this.setData({
      ec: {
        onInit: this.initChart.bind(this)
      }
    });
    this.refreshData();
  },

  onShow() {
    this.refreshData();
  },

  refreshData() {
    const historyList = wx.getStorageSync('sensor_history') || [];
    this.setData({ historyCount: historyList.length });
    if (historyList.length === 0) return;
    if (chartInstance) {
      this.updateChart(historyList);
    } else {
      this._pendingData = historyList;
    }
  },

  initChart(canvas, width, height, dpr) {
    chartInstance = echarts.init(canvas, null, {
      width: width,
      height: height,
      devicePixelRatio: dpr
    });
    canvas.setChart(chartInstance);
    if (this._pendingData) {
      this.updateChart(this._pendingData);
      this._pendingData = null;
    } else {
      const historyList = wx.getStorageSync('sensor_history') || [];
      if (historyList.length) this.updateChart(historyList);
    }
    return chartInstance;
  },

  updateChart(historyList) {
    if (!chartInstance) return;
    const latest = historyList.slice(-30);
    const categories = latest.map(item => {
      const date = new Date(item.timestamp);
      return `${date.getMonth()+1}/${date.getDate()} ${date.getHours()}:${date.getMinutes()}`;
    });
    const seriesData = latest.map(item => {
      switch (this.data.currentParam) {
        case 'temp': return item.t;
        case 'hum': return item.h;
        case 'methane': return item.m;
        case 'dist': return item.d;
        case 'pm25': return item.p;
        default: return item.t;
      }
    });
    const option = {
      tooltip: { trigger: 'axis' },
      xAxis: {
        type: 'category',
        data: categories,
        axisLabel: { rotate: 30, fontSize: 10 }
      },
      yAxis: {
        type: 'value',
        name: this.getUnit(this.data.currentParam)
      },
      series: [{
        name: this.getParamName(this.data.currentParam),
        type: 'line',
        data: seriesData,
        smooth: true,
        lineStyle: { width: 2, color: this.getColorByParam(this.data.currentParam) },
        symbol: 'circle',
        symbolSize: 4,
        areaStyle: { opacity: 0.1 }
      }],
      grid: {
        containLabel: true,
        left: 45,
        right: 20,
        top: 40,
        bottom: 30
      }
    };
    chartInstance.setOption(option, true);
  },

  switchParam(e) {
    const param = e.currentTarget.dataset.param;
    this.setData({ currentParam: param }, () => {
      const historyList = wx.getStorageSync('sensor_history') || [];
      if (historyList.length && chartInstance) {
        this.updateChart(historyList);
      } else {
        this.refreshData();
      }
    });
  },

  getParamName(param) {
    const map = { temp: '温度', hum: '湿度', methane: '甲烷浓度', dist: '顶板距离', pm25: 'PM2.5' };
    return map[param];
  },

  getColorByParam(param) {
    const colors = { temp: '#e67e22', hum: '#3498db', methane: '#9b59b6', dist: '#2c3e50', pm25: '#e74c3c' };
    return colors[param];
  },

  getUnit(param) {
    const units = { temp: '°C', hum: '%RH', methane: '%LEL', dist: 'cm', pm25: 'µg/m³' };
    return units[param];
  }
});