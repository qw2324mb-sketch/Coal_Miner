// pages/index/index.js
Page({
  data: {
    uid: "0fe8bed8a042411db0eeeb65ded3ed05",
    temp: '--',
    hum: '--',
    methane: '--',
    dist: '--',
    pm25: '--',
    alertMsg: '设备状态正常',
    alertClass: '',
    soundEnabled: false,      // 声音开关，默认关闭
  },

  audioContext: null,         // 音频实例

  onLoad() {
    this.initAudio();         // 初始化音频
    this.fetchSensorData();
    setInterval(() => this.fetchSensorData(), 3000);
  },

  // 初始化音频
  initAudio() {
    const innerAudioContext = wx.createInnerAudioContext();
    innerAudioContext.src = '/utils/sound/beep.mp3';   // 请确保文件存在
    innerAudioContext.autoplay = false;
    innerAudioContext.onError((res) => {
      console.error('音频加载失败', res);
    });
    this.audioContext = innerAudioContext;
  },

  // 用户点击声音开关
  toggleSound() {
    const newState = !this.data.soundEnabled;
    this.setData({ soundEnabled: newState });
    if (newState) {
      this.playBeep();        // 开启时播放测试音
      wx.showToast({ title: '声音已开启', icon: 'none' });
    } else {
      wx.showToast({ title: '声音已关闭', icon: 'none' });
    }
  },

  // 播放提示音
  playBeep() {
    if (!this.audioContext) return;
    this.audioContext.stop();
    this.audioContext.play();
  },

  fetchSensorData() {
    wx.request({
      url: 'https://apis.bemfa.com/va/getmsg',
      data: {
        uid: this.data.uid,
        topic: 'Worker',
        type: 1,
        num: 1
      },
      success: (res) => {
        console.log('API响应:', res.data);
        if (res.data && res.data.data && res.data.data.length > 0) {
          const rawMsg = res.data.data[0].msg;
          try {
            const data = JSON.parse(rawMsg);
            this.setData({
              temp: data.t?.toFixed(1) || '--',
              hum: data.h?.toFixed(1) || '--',
              methane: data.m?.toFixed(1) || '--',
              dist: data.d?.toFixed(1) || '--',
              pm25: data.p?.toFixed(1) || '--',
            });
            this.checkAlerts(data);
            this.saveHistoryData(data);
          } catch (e) {
            console.error('JSON解析失败', e);
          }
        } else {
          console.log('无数据');
        }
      },
      fail: (err) => {
        console.error('请求失败', err);
        this.setData({ alertMsg: '网络连接失败', alertClass: 'alert-danger' });
      }
    });
  },

  checkAlerts(data) {
    const methaneTh = wx.getStorageSync('alert_methane_threshold') || 15;
    const distTh = wx.getStorageSync('alert_dist_threshold') || 50;
    const pm25Th = wx.getStorageSync('alert_pm25_threshold') || 150;

    let alertMsg = '';
    let alertClass = '';
    const m = data.m;
    const d = data.d;
    const p = data.p;

    if (m >= methaneTh) {
      alertMsg = `⚠️ 甲烷浓度超限: ${m.toFixed(1)}%LEL (阈值 ${methaneTh})`;
      alertClass = 'alert-danger';
    } else if (d < distTh) {
      alertMsg = `⚠️ 顶板距离过近: ${d.toFixed(1)}cm (阈值 ${distTh}cm)`;
      alertClass = 'alert-danger';
    } else if (p >= pm25Th) {
      alertMsg = `⚠️ PM2.5浓度超标: ${p.toFixed(1)}µg/m³ (阈值 ${pm25Th})`;
      alertClass = 'alert-danger';
    } else {
      alertMsg = '设备状态正常';
      alertClass = '';
    }

    this.setData({ alertMsg, alertClass });

    if (alertClass === 'alert-danger') {
      // 震动（优先使用 heavy 强度，否则兼容）
      if (wx.canIUse('vibrateShort.type')) {
        wx.vibrateShort({ type: 'heavy' });
      } else {
        wx.vibrateShort();
        setTimeout(() => wx.vibrateShort(), 50);
      }
      // 声音提醒（如果用户已开启）
      if (this.data.soundEnabled) {
        this.playBeep();
      }
    }
  },

  saveHistoryData(data) {
    const now = Date.now();
    const historyItem = {
      timestamp: now,
      timeStr: new Date(now).toLocaleString(),
      t: data.t,
      h: data.h,
      m: data.m,
      d: data.d,
      p: data.p
    };
    let historyList = wx.getStorageSync('sensor_history') || [];
    historyList.push(historyItem);
    if (historyList.length > 200) historyList.shift();
    wx.setStorageSync('sensor_history', historyList);
    console.log('已保存历史数据，共', historyList.length, '条');
  },

  gotoHistory() {
    wx.navigateTo({
      url: '/pages/history/history'
    });
  }
});